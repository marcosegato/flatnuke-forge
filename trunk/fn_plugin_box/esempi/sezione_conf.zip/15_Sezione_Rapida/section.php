Sezione di prova
