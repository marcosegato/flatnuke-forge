<?
define("_THEME_VER", 1);
define("_THEME_DOCTYPE", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n");

function create_menu_horiz() {
	$mod = getparam("mod", PAR_GET, SAN_FLAT);
	$father_mod = explode("/", $mod);
	global $theme;
	// get menu items
	$menu_links = list_sections("sections", "links");
	$menu_names = list_sections("sections", "names");
	if($menu_links == null)
		return;
	// print menu
	$menu_item = _HOMEMENUTITLE;	// homesite
	echo "<div id=\"menu\"><ul>";
	$class = ($mod == "") ? " class=\"active\"":"";
	echo "\n<li$class><a href=\"index.php\" title=\""._FINDH."\">$menu_item</a></li>";
	for ($i=0; $i < count($menu_links); $i++) {
		$father_sect = explode("/", $menu_names[$i]);
		$class = ($father_mod[0] == $father_sect[0]) ? " class=\"active\"":"";
		echo "\n<li$class>$menu_links[$i]</li>";
	}
	echo "</ul></div>";
}
function OpenBlock($img, $title) {
	echo "<li>\n<h2>$title</h2>\n";
}
// close a block
function CloseBlock() {
	echo "</li>\n";
}
// function to create footer site
function CreateFooterSite() {
	echo "<p>";
	$footer_elements = get_footer_array();
	echo $footer_elements['img_fn']." ";
	echo $footer_elements['img_w3c']." ";
	echo $footer_elements['img_css']." ";
	echo $footer_elements['img_rss']." ";
	echo $footer_elements['img_mail']."<br>";
	echo $footer_elements['legal']."<br>";
	echo $footer_elements['time'];
	echo "</p>";
}
// open table title
function OpenTableTitle($title) {
	echo "<h2>$title</h2>\n";
}
// close table title
function CloseTableTitle() {echo "\n";}
// close table title for news footer
function CreateFootNews($text) {
	$text = str_replace(".php", "", $text);
	echo "<div class=\"credits\">\n";
	$news_link = get_news_link_array($text);
	echo "<p class=\"file\"><small>".$news_link['news_infos']."</small></p>";
	echo "<p class=\"posted\">\n";
	echo $news_link['link_read']." ";
	echo $news_link['link_comment']." ";
	echo $news_link['link_print']." ";
	if (is_admin()) echo $news_link['link_modify']." ";
	if (is_admin()) echo $news_link['link_delete']." ";
	echo "</p>\n";
	echo "</div>\n";
}
// close a normal table
function OpenTable() {
	echo "<p>\n";
}
// close a normal table
function CloseTable() {
	echo "</p>\n";
}
// close a normal table
function OpenMotd() {
	echo "<p>\n";
}
// close a normal table
function CloseMotd() {
	echo "</p>\n";
}

// open block of main menu
function OpenBlockMenu() {
}
// close block menu
function CloseBlockMenu() {}

