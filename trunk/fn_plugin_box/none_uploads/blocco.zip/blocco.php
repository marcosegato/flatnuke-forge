<?
echo "this is a simple test!";
?>
